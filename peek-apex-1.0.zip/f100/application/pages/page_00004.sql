prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.6'
,p_default_workspace_id=>7876659189632864
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'PEEK'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(8070236541641414)
,p_name=>'Permission Visualiser'
,p_alias=>'PERMISSION-VISUALISER'
,p_step_title=>'Permission Visualiser'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9107051150044376)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'PEEK'
,p_last_upd_yyyymmddhh24miss=>'20220617013238'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8084850153704201)
,p_plug_name=>'IAM Visualisation'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-none'
,p_plug_template=>wwv_flow_api.id(7972930457641270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>12
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(id) as ID,',
'    parent_nodes as PARENT_ID,',
'    node_name as LABEL,',
'    node_color as COLORVALUE,',
'    to_number(node_size) as SIZEVALUE,',
'    node_link as LINK,',
'    node_tooltip as INFOSTRING ',
' from TREES',
'WHERE tree_name = :IAM_USER_NAME'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.D3.COLL.TREE'
,p_ajax_items_to_submit=>'IAM_USER_NAME'
,p_plug_query_num_rows=>50000
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_02=>'COLUMN'
,p_attribute_04=>'N'
,p_attribute_11=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'  "trdur":                       500,',
'  "css_class_node":              "com_oracle_apex_d3_tree_node",',
'  "css_class_leafnode":          "com_oracle_apex_d3_tree_leafnode",',
'  "css_class_link":              "com_oracle_apex_d3_tree_link",',
'  "circle_radius_min":           10,',
'  "circle_radius_max":           10,',
'  "legend_column_width":         200,',
'  "root_label":                  "Tree root",',
'  "show_coll_child_cnt":         true,',
'  "show_coll_child_template":    " (#CNT#)",',
'  "offset_scrollbars":           20, ',
'  "margin":                      {"top": 20, "right": 120, "bottom": 20, "left": 120}',
'}'))
,p_attribute_12=>'LABEL'
,p_attribute_13=>'SIZEVALUE'
,p_attribute_14=>'ID'
,p_attribute_15=>'PARENT_ID'
,p_attribute_16=>'COLORVALUE'
,p_attribute_18=>'INFOSTRING'
,p_attribute_19=>'180'
,p_attribute_20=>'N'
,p_attribute_21=>'3000'
,p_attribute_24=>'Y'
,p_attribute_25=>'{"red":"red", "blue":"blue", "green":"green", "yellow":"yellow", "gray":"gray" "black":"black", "orange":"orange"}'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8084937299704202)
,p_name=>'IAM_USER_NAME'
,p_item_sequence=>10
,p_prompt=>'User Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DISTINCT TREE_NAME AS DISPLAY, TREE_NAME AS VALUE FROM TREES ORDER BY TREE_NAME ASC'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(8043056066641337)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
