prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.6'
,p_default_workspace_id=>7876659189632864
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'PEEK'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(8070236541641414)
,p_name=>'Policies'
,p_alias=>'POLICIES'
,p_step_title=>'Policies'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9107051150044376)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'PEEK'
,p_last_upd_yyyymmddhh24miss=>'20220616214847'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(8301094420061856)
,p_name=>'Policies'
,p_template=>wwv_flow_api.id(7972930457641270)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT u.NAME as "USER NAME", c.NAME as "COMPARTMENT NAME", gr.statement, gr.GRANT_TYPE',
'FROM USERS u',
'INNER JOIN GROUPS gp ON (u.id = gp.USER_ID)',
'INNER JOIN GRANTS gr ON gr.GROUP_ID = gp.ID',
'INNER JOIN COMPARTMENTS c on gr.COMPARTMENT_ID = c.ID',
'WHERE (u.NAME = :P_IAM_USER_NAME or :P_IAM_USER_NAME = ''all'') AND gr.GRANT_TYPE = ''explicit'''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(8006364755641301)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8301499530061869)
,p_query_column_id=>1
,p_column_alias=>'USER NAME'
,p_column_display_sequence=>10
,p_column_heading=>'User Name'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8301847472061870)
,p_query_column_id=>2
,p_column_alias=>'COMPARTMENT NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Compartment Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8302255407061870)
,p_query_column_id=>3
,p_column_alias=>'STATEMENT'
,p_column_display_sequence=>30
,p_column_heading=>'Statement'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8302605052061871)
,p_query_column_id=>4
,p_column_alias=>'GRANT_TYPE'
,p_column_display_sequence=>40
,p_column_heading=>'Grant Type'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8085369867704206)
,p_name=>'P_IAM_USER_NAME'
,p_item_sequence=>40
,p_prompt=>'IAM User Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DISTINCT USERS.NAME AS DISPLAY, USERS.NAME AS VALUE FROM USERS ORDER BY USERS.NAME ASC'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'all'
,p_lov_null_value=>'all'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>1
,p_field_template=>wwv_flow_api.id(8043056066641337)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
